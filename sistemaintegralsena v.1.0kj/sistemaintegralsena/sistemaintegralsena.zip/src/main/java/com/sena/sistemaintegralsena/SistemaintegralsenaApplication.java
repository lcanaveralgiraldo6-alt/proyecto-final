package com.sena.sistemaintegralsena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaintegralsenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaintegralsenaApplication.class, args);
	}

}
